package document;

public interface Document {
    void open();
}
