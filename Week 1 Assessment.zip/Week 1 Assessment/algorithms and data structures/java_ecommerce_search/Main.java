import java.util.*;

public class Main {
    public static void main(String[] args) {
        List<Product> products = new ArrayList<>();
        products.add(new Product(3, "Mouse", "Electronics"));
        products.add(new Product(1, "Laptop", "Electronics"));
        products.add(new Product(2, "Keyboard", "Electronics"));

        int targetId = 2;

        Product foundLinear = Search.linearSearch(products, targetId);
        Collections.sort(products);
        Product foundBinary = Search.binarySearch(products, targetId);

        System.out.println(foundLinear != null ? foundLinear.productName : "Not found");
        System.out.println(foundBinary != null ? foundBinary.productName : "Not found");
    }
}
