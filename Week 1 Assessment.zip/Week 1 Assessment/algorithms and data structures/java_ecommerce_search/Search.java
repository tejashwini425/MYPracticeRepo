import java.util.List;

public class Search {
    public static Product linearSearch(List<Product> products, int targetId) {
        for (Product p : products) {
            if (p.productId == targetId) {
                return p;
            }
        }
        return null;
    }

    public static Product binarySearch(List<Product> products, int targetId) {
        int left = 0, right = products.size() - 1;
        while (left <= right) {
            int mid = (left + right) / 2;
            Product midProduct = products.get(mid);
            if (midProduct.productId == targetId) {
                return midProduct;
            } else if (midProduct.productId < targetId) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }
}
