package main;

import model.Product;
import service.InventoryManager;

public class InventorySystemApp {
    public static void main(String[] args) {
        InventoryManager manager = new InventoryManager();

        Product p1 = new Product(101, "Mouse", 50, 299.99);
        Product p2 = new Product(102, "Keyboard", 30, 499.49);
        Product p3 = new Product(103, "Monitor", 20, 7999.99);

        manager.addProduct(p1);
        manager.addProduct(p2);
        manager.addProduct(p3);

        p2.price = 450.00;
        manager.updateProduct(p2);

        manager.deleteProduct(101);

        Product fetched = manager.getProduct(103);
        if (fetched != null) {
            System.out.println(fetched.productName + " - " + fetched.quantity + " - " + fetched.price);
        }
    }
}
