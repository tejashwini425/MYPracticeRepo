
CREATE TABLE Customers (
    CustomerID NUMBER PRIMARY KEY,
    Name VARCHAR2(100),
    DOB DATE,
    Balance NUMBER,
    LastModified DATE,
    IsVIP CHAR(1) DEFAULT 'N'
);

CREATE TABLE Accounts (
    AccountID NUMBER PRIMARY KEY,
    CustomerID NUMBER,
    AccountType VARCHAR2(20),
    Balance NUMBER,
    LastModified DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

CREATE TABLE Employees (
    EmployeeID NUMBER PRIMARY KEY,
    Name VARCHAR2(100),
    Position VARCHAR2(50),
    Salary NUMBER,
    Department VARCHAR2(50),
    HireDate DATE
);

CREATE TABLE Loans (
    LoanID NUMBER PRIMARY KEY,
    CustomerID NUMBER,
    LoanAmount NUMBER,
    InterestRate NUMBER,
    StartDate DATE,
    EndDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

INSERT INTO Customers VALUES (1, 'John Doe', TO_DATE('1960-01-01', 'YYYY-MM-DD'), 10000, SYSDATE, 'N');
INSERT INTO Customers VALUES (2, 'Jane Smith', TO_DATE('1985-02-02', 'YYYY-MM-DD'), 5000, SYSDATE, 'N');

INSERT INTO Accounts VALUES (1, 1, 'Savings', 1000, SYSDATE);
INSERT INTO Accounts VALUES (2, 2, 'Savings', 2000, SYSDATE);

INSERT INTO Employees VALUES (1, 'Alice Johnson', 'Manager', 70000, 'HR', TO_DATE('2015-06-15', 'YYYY-MM-DD'));
INSERT INTO Employees VALUES (2, 'Bob Brown', 'Developer', 60000, 'IT', TO_DATE('2017-03-20', 'YYYY-MM-DD'));

INSERT INTO Loans VALUES (1, 1, 10000, 5.0, SYSDATE, ADD_MONTHS(SYSDATE, 60));
INSERT INTO Loans VALUES (2, 2, 15000, 6.5, SYSDATE, ADD_MONTHS(SYSDATE, 48));

CREATE OR REPLACE PROCEDURE ProcessMonthlyInterest IS
    v_updated_balance NUMBER;
BEGIN
    FOR acc IN (SELECT AccountID, Balance FROM Accounts WHERE AccountType = 'Savings') LOOP
        v_updated_balance := acc.Balance + (acc.Balance * 0.01);
        UPDATE Accounts
        SET Balance = v_updated_balance
        WHERE AccountID = acc.AccountID;

        DBMS_OUTPUT.PUT_LINE('Interest applied: Account ' || acc.AccountID ||
                             ', New Balance: ' || TO_CHAR(v_updated_balance));
    END LOOP;
END;
/

SET SERVEROUTPUT ON;
BEGIN
    ProcessMonthlyInterest;
END;
/

CREATE OR REPLACE PROCEDURE UpdateEmployeeBonus (
    p_department IN VARCHAR2,
    p_bonus_percent IN NUMBER
) IS
    v_new_salary NUMBER;
BEGIN
    FOR emp IN (SELECT EmployeeID, Name, Salary FROM Employees WHERE Department = p_department) LOOP
        v_new_salary := emp.Salary + (emp.Salary * p_bonus_percent / 100);
        UPDATE Employees
        SET Salary = v_new_salary
        WHERE EmployeeID = emp.EmployeeID;

        DBMS_OUTPUT.PUT_LINE('Bonus applied to ' || emp.Name || 
                             ', New Salary: ' || TO_CHAR(v_new_salary));
    END LOOP;
END;
/

BEGIN
    UpdateEmployeeBonus('IT', 10);
END;
/

CREATE OR REPLACE PROCEDURE TransferFunds (
    p_from_account IN NUMBER,
    p_to_account IN NUMBER,
    p_amount IN NUMBER
) IS
    v_balance NUMBER;
BEGIN
    SELECT Balance INTO v_balance FROM Accounts WHERE AccountID = p_from_account;

    IF v_balance >= p_amount THEN
        -- Deduct
        UPDATE Accounts SET Balance = Balance - p_amount WHERE AccountID = p_from_account;

        -- Add
        UPDATE Accounts SET Balance = Balance + p_amount WHERE AccountID = p_to_account;

        DBMS_OUTPUT.PUT_LINE('Transfer successful: ₹' || p_amount || 
                             ' from Account ' || p_from_account || 
                             ' to Account ' || p_to_account);
    ELSE
        DBMS_OUTPUT.PUT_LINE('Transfer failed: Insufficient balance in Account ' || p_from_account);
    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Transfer failed: One or both account IDs not found.');
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Unexpected error: ' || SQLERRM);
END;
/

BEGIN
    TransferFunds(1, 2, 500);
END;
/
