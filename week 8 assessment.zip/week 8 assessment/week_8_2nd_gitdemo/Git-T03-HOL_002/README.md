# Git Ignore Hands-On Lab

This repository demonstrates how to use .gitignore to exclude unwanted files and folders.

Ignored:
- All .log files
- log/ folder

